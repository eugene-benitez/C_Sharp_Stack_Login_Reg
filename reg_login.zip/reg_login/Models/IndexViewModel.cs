using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace reg_login.Models
{
    public class IndexViewModel

    {
        public User NewUser { get; set; }
    }



}